import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LandingComponent } from './pages/landing/landing.component';
import { StudentslistComponent } from './pages/Studentslist/Studentslist.component';

const routes: Routes = [
  {path: '',redirectTo : '/landing', pathMatch : 'full'},
  {path : 'landing', component: LandingComponent},
  {path : 'studentslist/:ref', component :StudentslistComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
