import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatabaseService } from 'src/app/services/database.service';
import { Usersdata } from 'src/app/services/users';
//import { Routes, RouterModule } from '@angular/router';

@Component({
  selector: 'app-studentslist',
  templateUrl: './studentslist.component.html',
  styleUrls: ['./studentslist.component.scss']
})
export class StudentslistComponent implements OnInit {
  learners: any;
  currentlearners = null;
  currentIndex = -1;
  message = '';
 

 constructor( public _database: DatabaseService) { }


  ngOnInit() {
    
  }

    delete() {
      this._database.deleteUser().subscribe(
          response => {
            console.log(response);
          
          },
          error => {
            console.log(error);
          });
        }
          //update user
          update() {
            this._database.updateUser(this.currentlearners.id, this.currentlearners)
              .subscribe(
                response => {
                  console.log(response);
                  this.message = 'The tutorial was updated successfully!';
                },
                error => {
                  console.log(error);
                });
    

}
}