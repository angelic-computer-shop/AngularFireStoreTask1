import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { DatabaseService } from 'src/app/services/database.service';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent implements OnInit {
  title='firebasetasks';
  persons:any;
  constructor(public _data:DatabaseService) { }
  AddUsers(UserData:NgForm){
    this._data.AddUser(UserData.value);
    
        }

  ngOnInit() {
    this._data.GetUsers().snapshotChanges().subscribe(action =>{
      console.log('action');
     this.persons =action;

     //check if the name exist
     //action.map(element =>
    // {
    //   const UserInfo = element as User;
    

   //  if (this.persons.name=="nkele"){
      // console.log("name exist");
     //}
   })
  }

    }

  
  


