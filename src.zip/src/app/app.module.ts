import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule} from '@angular/forms';
import {AngularFireModule} from '@angular/fire';
import {AngularFirestoreModule} from '@angular/fire/firestore';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LandingComponent } from './pages/landing/landing.component';
import { StudentslistComponent } from './pages/studentslist/studentslist.component';
import { environment } from 'src/environments/environment';
import { DatabaseService } from './services/database.service';
import { from } from 'rxjs';

@NgModule({
  declarations: [
    AppComponent,
    LandingComponent,
   StudentslistComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFirestoreModule

  ],
  providers: [DatabaseService],
  bootstrap: [AppComponent]
})
export class AppModule { }
