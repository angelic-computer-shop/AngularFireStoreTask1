import { Injectable } from '@angular/core';

import {AngularFireModule} from '@angular/fire';
import { AngularFirestore } from '@angular/fire/firestore';
import { from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DatabaseService {

  constructor(public _fire:AngularFirestore) { }

  //Add Users functio
  AddUser(data)
  {
    return this._fire.collection('users').add(data).then(results=>{
      console.log('Successfully added user')
    }).catch(err=> {
      console.log('Err occured:',err)
    });
  }
    //Get Data from Firebase store

    GetUsers()
    {
      return this._fire.collection('Users');
    }

    //Delete Students
    deleteUser(){
      return this._fire.collection('users').doc(name).delete();
    }

    //Update Users
    updateUser(userKey, data){
      
      return this._fire.collection('users').doc(userKey).set(data);
    }

  
}
