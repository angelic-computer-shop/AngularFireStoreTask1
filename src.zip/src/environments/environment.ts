// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  
  firebaseConfig : {
    apiKey: "AIzaSyDsX8PuViB3qMkFMsKQur6Yjc5FqRXefe8",
    authDomain: "angularfiretask-d7640.firebaseapp.com",
    databaseURL: "https://angularfiretask-d7640.firebaseio.com",
    projectId: "angularfiretask-d7640",
    storageBucket: "angularfiretask-d7640.appspot.com",
    messagingSenderId: "637093876118",
    appId: "1:637093876118:web:68eb91bb04d7e615e10db7"
  
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
